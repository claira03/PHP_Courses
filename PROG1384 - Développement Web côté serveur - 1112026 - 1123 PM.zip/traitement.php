<!--
        auteur :Joel Boudreau
        date : 2026
       
-->
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8" />
    <title>Traitement form</title>
</head>

<body>
    <?php

    $nom = $_GET['txtNom'];
    $email = $_GET['txtCourriel'];
    ?>
    Bienvenue <?php echo $nom; ?><br />
    Ton courriel est: <?php echo $email; ?>

</body>

</html>