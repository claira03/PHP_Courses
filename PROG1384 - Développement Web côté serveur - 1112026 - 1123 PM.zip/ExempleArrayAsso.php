﻿<!-- 
        auteur : Joel Boudreau
        date :  2026
        but :
-->
<!DOCTYPE html>
<html lang="fr">

<head>
        <meta charset="UTF-8" />
        <title>Exemple Array Assoc.</title>
</head>

<body>
        <?php
        $pays =  [
                'USA' => 'Etats-Unis',
                'CAN' => 'Canada',
                'MEX' => 'Mexique'
        ];

        $pays['ESP'] = 'Espagne';

        //asort($pays);
        var_dump($pays);

        foreach ($pays as  $country) {
                echo  $country . '<br />';
        }




        $ages = [
                'Joel' => 53,
                'Paul' => 28,
                'David' => 42
        ];


        $ages['Ghislain'] = 40;
        asort($ages);

        var_dump($ages);


        ?>


</body>

</html>