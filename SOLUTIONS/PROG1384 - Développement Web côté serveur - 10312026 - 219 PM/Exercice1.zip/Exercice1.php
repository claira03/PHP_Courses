<!--
        auteur :Joel Boudreau
        date : 2026
       
-->
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>template</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns" crossorigin="anonymous"></script>
    <script>



    </script>
    <style>
        #content {
            margin: 25px;
        }
    </style>
</head>

<body>
    <div class="jumbotron text-center" style="margin-bottom:0">
        <h1><i class="bi bi-code"></i> PROG-1300 <i class="bi bi-code-slash"></i></h1>
        <p>Programmation Web côté serveur avec logiciels libres</p>
    </div>
    <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
        <a class="navbar-brand" href="#">Exercice</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="collapsibleNavbar">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="https://www.w3schools.com/jsref/default.asp">W3Schools JavaScript
                        Références</a>
                </li>
            </ul>
        </div>
    </nav>
    <?php
    const NOMBRE_MAX = 1000;
    const FACTO_N = 8;
    ?>
    <div id="content">
        <h1>Exercice 1</h1>
        <hr />

        <!--<h2>Les nombres impaires de 1 à <?php echo NOMBRE_MAX; ?></h2>-->
        <!-- ci-bas tag spécial pour echo automatique -->
        <h2>Les nombres impaires de 1 à <?= NOMBRE_MAX; ?></h2>

        <p><?php
            for ($i = 1; $i <= NOMBRE_MAX; $i += 2) {
                echo "$i ";
            }
            ?></p>
        <br />
        <h2>Calcule du factoriel de <?= FACTO_N; ?></h2>

        <?php
        $facto = 1;
        for ($i = 2; $i <= FACTO_N; $i++) {
            $facto = $facto * $i;
        }

        echo '<p>' . FACTO_N . "! = $facto</p>\n";
        ?>
    </div>
</body>

</html>